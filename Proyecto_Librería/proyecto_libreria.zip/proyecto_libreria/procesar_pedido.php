<?php
?>	
<!DOCTYPE html>
<html>
    <head>
        <meta charset = "UTF-8">
        <title>Procesar Pedido</title>	
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">	
        <script type = "text/javascript" src = ""></script>
    </head>
    <body>
        <div class="container-fluid">
            <div class="col-md-12 order-md-1">
                <h4>Librería</h4>
                <?php
                ?>	
            </div>
        </div>
    </body>
</html>

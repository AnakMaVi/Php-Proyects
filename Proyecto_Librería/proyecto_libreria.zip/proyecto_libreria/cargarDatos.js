
// function cargarLibros(){
//     var xhttp = new XMLHttpRequest();
//     xhttp.open("GET", "bd.php", true);
  
//     xhttp.onreadystatechange = function () {
//         if (this.readyState == 4 && this.status == 200) {
//             // crear lista
          
//             // meter los datos de la respuesta en un array
//             var categorias = JSON.parse(this.response);
//            categorias = categorias.libro;
        
//             // para cada elemento del array 
//             const tbl = document.createElement("table");
//             const tblBody = document.createElement("tbody");
          
//             for (var i = 0; i < categorias.length; i++) {
//                 //se crea un elemento ul con el campo  nombre 
//                 const fila=document.createElement("tr");
  
//                 for (var j = 0; j < 6; j++) {
//                     elementos={0:"isbn",1:"titulo",2:"escritores",3:"genero",4:"numpaginas",5:"imagen",};
  
//                     var atributo=elementos[j];
//                 const columna= document.createElement("td");
//                 const cellText = document.createTextNode(categorias[i][atributo]);
//                 columna.appendChild(cellText);
                
//                 fila.appendChild(columna);
//                 }
  
               
  
             
//                 tblBody.appendChild(fila);
//             }
//             tbl.appendChild(tblBody);
//             document.body.appendChild(tbl);
//   // sets the border attribute of tbl to '2'
//   tbl.setAttribute("border", "2");
//             var body = document.getElementById("contenido");
//             // eliminar el contenido actual
//             body.innerHTML = "";
//             body.appendChild(tbl);
  
//         }
//     };
  
//     xhttp.send();
//     // para que no se siga el link que llama a esta función
//     return false;
//   }
  

  function cargarGeneros() {
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "bd.php", true);
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // crear lista
            var lista = document.createElement("ul");
            // meter los datos de la respuesta en un array
            var categorias = JSON.parse(this.response);
            // para cada elemento del array 
            for (var i = 0; i < categorias.length; i++) {
                //se crea un elemento ul con el campo  nombre 
               
               
                var elemementoLista =  document.createElement("li");
                var funcion=categorias[i]["nombre"];
                funcion;
                elemementoLista.innerHTML ="<section id="+categorias[i]['nombre']+"></section>"+
               " <a href = '#' onclick = 'return cargar_libros_generos();' name="+ funcion +">"+categorias[i]["nombre"]+"</a>"	;
                 
                // se añade a la lista

                lista.appendChild(elemementoLista);
            }
            var body = document.getElementById("generos");
            // eliminar el contenido actual
            body.innerHTML = "";
            body.appendChild(lista);

        }
    };

    xhttp.send();
    // para que no se siga el link que llama a esta función
    return false;
}
  

function cargar_libros_generos(){
    var tipo =document.getElementsByName("Drama")
   document.write(tipo.name);
        var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "bd.php", true);
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // crear lista
                var lista = document.createElement("ul");
                // meter los datos de la respuesta en un array
                var categorias = JSON.parse(this.response);
                // para cada elemento del array 
                for (var i = 0; i < categorias.length; i++) {
                  if ( categorias[i]["genero"]==genero){
                    //se crea un elemento ul con el campo  nombre 
                    var elemementoLista = document.createElement("li");
                    elemementoLista.innerHTML =categorias[i]["nombre"];
                    // se añade a la lista
                    lista.appendChild(elemementoLista);}
                }
                var body = document.getElementsByTagName(genero);
                // eliminar el contenido actual
                body.innerHTML = "";
                body.appendChild(lista);
    
            }
        };
    
        xhttp.send();
        // para que no se siga el link que llama a esta función
        return false;
    }
<?php
function cargar_libros_generos() {
    $file=simplexml_load_file( 'libros.xml' ) ;
    $json= json_encode($file);
print_r($json);

}
cargar_libros_generos() ;


?>
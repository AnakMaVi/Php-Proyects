<?php

function comprobar_usuario($usuario, $password) {
    $datos = simplexml_load_file("configuracion.xml");
    $usuarioConf = $datos->xpath("//usuario");
    $claveConf = $datos->xpath("//clave");
    $confUsu = [];
    $confUsu[] = $usuarioConf[0];
    $confUsu[] = $claveConf[0];

    return ($usuario == $confUsu[0] && $password == $confUsu[1]);
}


    function cargar_generos(){

        $gen1 = array("cod" => 1, "nombre" => "Ciencia Ficción");
        $gen2 = array("cod" => 2, "nombre" => "Comedia");
        $gen3 = array("cod" => 3, "nombre" => "Distopías");
        $gen4 = array("cod" => 4, "nombre" => "Drama");
        $gen5 = array("cod" => 5, "nombre" => "Histórica");
        $gen6 = array("cod" => 6, "nombre" => "Terror");
        $array = array($gen1, $gen2,$gen3,$gen4,$gen5,$gen6);
        return $array;
       
    }

    function cargar_libros_generos($nombre) {
        $categorias = cargar_generos();
    
        foreach ($categorias as $indice => $valor) {
            if ($valor["nombre"] == $nombre) {
                return $valor;
            }
        }
    
        return null;
    }

    function cargar_libros() {

        $file=simplexml_load_file( 'libros.xml' ) ;
        return json_encode($file);
    }


    function cargar_productos($isbn) {

        $productos = cargar_libros();
    
        $productosSeleccionados = [];
    
        foreach ($file->libro as $nodo) 
        {
            foreach ($isbn as $idProducto) {
               if ($idProducto==$nodo->isbn){
                $productosSeleccionados[]=$file->libro[$idProducto];}
            }
        }
    
        return $productosSeleccionados;
    }
   

    cargar_libros();
?>
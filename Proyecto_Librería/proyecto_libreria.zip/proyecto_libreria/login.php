<?php
require_once 'bd.php';
/*  Formulario de login habitual
    si va bien abre sesión, guarda el nombre de usuario y redirige a principal.php
    si va mal, mensaje de error */
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Llama la funcion para comprobar si el usuario y clave en el doc XML.
    $usuario = comprobar_usuario($_POST['usuario'], $_POST['clave']);

    if ($usuario === false) {
        $error = true;
        $usuario = $_POST['usuario'];
        echo"<p>Usuario o clave incorrectos</p>";
    } else {
        session_start();
        $_SESSION['usuario'] = $_POST['usuario'];
        $_SESSION['carrito'] = $_POST['carrito'];
        header("Location: principal.php");
        return;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Formulario de login</title>
        <meta charset = "UTF-8">
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">			
    </head>	
    <body>
        <div class="container-fluid">
            <div class="col-md-4 order-md-1">
                <h4>Librería</h4>
                <section id = "login">
                    <form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method = "POST">
                        <div class="form-group">
                            <label for="usuario">Usuario</label>
                            <input class="form-control" id = "usuario" name = "usuario" type = "text">			
                            <label for="clave">Clave</label>
                            <input class="form-control" id = "clave" name = "clave" type = "password">					

                        </div>
                        <input class="btn btn-primary btn-lg" value="Iniciar Sesión" type = "submit">
                    </form>
                </section>
            </div>
        </div>
    </body>
</html>
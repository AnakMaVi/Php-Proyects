<header>
    Usuario: <?php echo $_SESSION['usuario']; ?>
    <br>
    <script type = "text/javascript" src = "cargarDatos.js"></script>	
    <br> Menú: 
  

    <a href="#"  onclick="return cargarGeneros()"  >Listado de Generos</a> /
    <a href="#" onclick="return cargarLibros()" >Listado de Libros</a> / 
    <a href="">Ver carrito</a> /
    <a href="logout.php">Cerrar sesión</a>
   
</header>
<hr>
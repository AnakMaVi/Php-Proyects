<?php
function cargar_libros(){
    $file=simplexml_load_file( 'libros.xml' ) ;
    $json= json_encode($file);
print_r($json);}
cargar_libros();

?>